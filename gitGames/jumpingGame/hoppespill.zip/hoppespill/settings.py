#color 
WHITE = (255, 255, 255)
LIGHTBLUE = (200, 228, 230)
BLUE = (12, 12, 117)

#game constants
playerSize = 60
lineWidth = 20
MaxPlatforms = 10
start = 100
l = [1,2,3,4]
lvls = [i * 100 for i in l]
fps = 60
running = True

leftScore = 0
rightScore = 0
scores = [leftScore, rightScore]
